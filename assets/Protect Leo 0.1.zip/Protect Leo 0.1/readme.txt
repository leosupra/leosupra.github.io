# Protect Leo

## Description

After the volcanic eruption, Leo faces a serious challenge, help him survive as long as possible!

## Installation

2. Run "Protect Leo.exe" file (no installation required)

## Controls

- **Arrow Keys**: Move Leo Up and down

## License

This game is free to play and not for sale.

## Author

Developed by Ayo

